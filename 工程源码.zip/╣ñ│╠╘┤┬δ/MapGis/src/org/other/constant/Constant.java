package org.other.constant;

public class Constant {
	//Btn�ı�ʶ
	public static final int BTN_FLAG_MESSAGE = 0x01;
	public static final int BTN_FLAG_Contents = 0x01 << 1;
	public static final int BTN_FLAG_Friends = 0x01 << 2;
	public static final int BTN_FLAG_MapPublic = 0x01 << 3;
	public static final int BTN_FLAG_MapFriendsWith = 0x01 << 4;
	public static final int BTN_FLAG_MapNews = 0x01 << 5;
	
	//Fragment�ı�ʶ
	public static final String FRAGMENT_FLAG_MESSAGE = "��Ϣ"; 
	public static final String FRAGMENT_FLAG_Contents = "+"; 
	public static final String FRAGMENT_FLAG_Friends = "����"; 
	public static final String FRAGMENT_FLAG_MapPublic = "������Ϣ"; 
	public static final String FRAGMENT_FLAG_MapFriendsWith = "������"; 
	public static final String FRAGMENT_FLAG = "���Ѷ�̬"; 
	
	public static final String FRAGMENT_FLAG_SIMPLE = "simple"; 
	
	
}
