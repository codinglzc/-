package com.basic.model;


public class MessagePlusEndity {

	// 功能名称
	public String name;
	// 功能图标
	public int icon;
	// 功能编号
	public int position; 

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIcon() {
		return icon;
	}

	public void setIcon(int icon) {
		this.icon = icon;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}
}
