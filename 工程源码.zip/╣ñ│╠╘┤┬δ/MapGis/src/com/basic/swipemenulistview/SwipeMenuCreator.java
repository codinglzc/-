package com.basic.swipemenulistview;


/**
 * 
 * @author licaomeng
 * @date 2015-7-14
 *
 */
public interface SwipeMenuCreator {

	void create(SwipeMenu menu);
}
